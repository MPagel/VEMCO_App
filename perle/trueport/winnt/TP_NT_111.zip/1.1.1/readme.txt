TRUEPORT FOR WINDOWS NT4.0/NT3.51 - 27/10/1999
===============================================

This is the third release of TruePort.

This release installs a daemon specific to Windows NT 4.0 or 3.51 as the
functions which support multi-threaded operation are different.

Known ESILs:

921. File Transfer using HyperTerminal fails. Resolved.


The TruePort package 1.1.1 consists of the following components and their versions:

Component		File			Version
=========================================================
TruePort Configurator	tp.exe			1.00
TruePort Daemon		TruePortd.exe		1.1.1
TruePort Driver		TruePort.sys		1.1.0
